# The Relay: write-up

> Draft. Sections marked **[after runs]** get their numbers from `tables.md` once the
> real Groq runs are done. Sections marked **[yours]** must be written by you, in your
> own words. The brief asks for your opinion and your experience there.

## 1. What I built and why
**[after runs]**: design summary (5 steps, see README diagram) + the one decision that shaped it most.

## 2. The real service and my stand-in
**[after runs]**: Table 1, how the limits were found, how the stand-in was calibrated, where it differs most.

## 3. Results
**[after runs]**: Tables 2a, 2b, quality on 20 questions, tokens per answer, the number nobody could guess.

## 4. Where the time goes
**[after runs]**: one slow request split into waiting / working / retrying (from `results/*_detail.jsonl`).

## 5. When a limit is hit
**[after runs]**

## Retrieval: quality versus cost
**[after runs]**: Table 3 (S1–S4), chosen setting and why, what retrieval does when the limit is close.

## How this library will mislead a naive retriever
Measured with plain BM25 over the three papers before any fixes:

1. **Shared training vocabulary across papers.** "Warmup", "learning rate" and "training stages"
   appear in all three papers. For *"What value of warmup_steps did the Transformer's
   learning-rate schedule use?"*, BM25 scores the right Attention page (17.1) only just above
   Moshi p.20 (16.3) and H-Net p.11 (16.1) with 250-word pieces. With 500-word pieces, Moshi
   p.19 ranks first. Three of the four passages the model reads are about the wrong paper.
   Fix: the understand step names the paper and retrieval filters to it (all four pieces are
   then from Attention), widening only if that finds nothing.
2. **Formulas in Unicode math letters are invisible to keyword search.** H-Net writes
   its boundary rule as `𝑏𝑡 = 1{𝑝𝑡≥0.5}` in math-italic characters. *"Above what boundary
   probability does H-Net mark a position as a chunk boundary?"* cannot match those characters.
   NFKC normalisation turns them into plain letters. Even then, the 250-word settings (S2, S3)
   still miss the 0.5, because the piece holding it is mostly formula fragments. The 120- and
   500-word settings find it.
3. **One question, two different numbers.** Attention uses beam 4 / α 0.6 for translation
   but beam 21 / α 0.3 for parsing, so *"what beam size did they use?"* gets a confident
   answer from whichever passage ranks first. H-Net's abstract says DNA data efficiency is
   "nearly 4×" and its introduction says "3.6×". "3.6" also appears in Moshi as a baseline's
   word error rate (3.6%).

Also seen: PDF extraction splits numbers and words ("2 .1T tokens", "T ext data"), flattens
tables so a value sits next to the wrong row label (Moshi's Depth Transformer
hyper-parameters, the Attention parsing table), and the reference lists match any query
with "attention" in a cited title (I drop them). Most importantly, **the retrieval score
cannot tell answerable from unanswerable**: the English-Romanian question, which the paper
does not answer, scores 2.95 per query word (S2), higher than 13 of the 16 answerable
questions. So refusing has to be done by the model reading the passages, not by a score
threshold.

## 6. Retries
**[after runs]**

## 7. What the person sees
**[after runs]**

## 8. What I'm unsure about, what I left out, what I learned
**[after runs]** + **[yours]** for "one thing that was new to you".

## Your feedback on Vaani
**[yours]**: visit https://www.vaani.dev/ and write 3–5 honest lines: what stood out, what
confused you, one thing you would change.

## How I worked with the assistant
**[yours]**: attach the real conversation export. Then, in half a page, your three most
important prompts and why, one thing it got wrong that you caught, one decision where you
overruled it, and what is distinctly yours.
