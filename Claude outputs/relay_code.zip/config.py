"""
Every number I chose lives here, so it is easy to find and change.
The limit numbers are starting guesses; probe_groq.py measures the real ones
and writes them to data/calibration.json, which overrides the defaults below.
"""
import json
import os

# ---------------------------------------------------------------- models
GROQ_URL = "https://api.groq.com/openai/v1"
STANDIN_URL = "http://127.0.0.1:8100/openai/v1"
MODEL_UNDERSTAND = "llama-3.1-8b-instant"   # small, cheap call: what is being asked
MODEL_DRAFT = "llama-3.1-8b-instant"        # writes the cited answer

# ---------------------------------------------------------------- what "fast" means (my choice)
PATIENCE_S = 10.0          # a person gives up if no first token within 10 s
DRAFT_RESERVE_S = 2.5      # need at least this much time left to start drafting
CALL_READ_TIMEOUT_S = 6.0  # a model call that is silent this long is treated as stuck
OPTIONAL_STEP_TIMEOUT_S = 2.0  # the "understand" step is optional: if it is slow, go on without it
ANSWER_MAX_TOKENS = 300    # keep answers short: faster, cheaper, fewer places to go wrong
LEAN_MAX_TOKENS = 200

# ---------------------------------------------------------------- retries
MAX_RETRIES_429 = 2        # only if retry-after still fits before the deadline
MAX_RETRIES_ERROR = 1      # 5xx / connection error / stuck call, before first token only

# ---------------------------------------------------------------- daily budget
LEAN_WHEN_DAILY_LEFT = 0.20   # below 20% of the day's budget: skip optional steps

# ---------------------------------------------------------------- limits (defaults, overwritten by calibration)
LIMITS = {
    "rpm": 30,          # requests per minute
    "tpm": 6000,        # tokens per minute
    "rpd": 14400,       # requests per day
    "tpd": 500000,      # tokens per day
}
SAFETY = 0.9            # use only 90% of a limit, the rest absorbs estimation error
TPM_COUNTS_MAX_TOKENS = True   # does the provider count max_tokens against TPM up front?
                               # probe_groq.py tests this; calibration.json overrides it

# price used for "cost per 1,000 answers" (USD per million tokens); free tier itself costs $0
PRICE_IN_PER_M = 0.05
PRICE_OUT_PER_M = 0.08

# ---------------------------------------------------------------- retrieval settings (Table 3)
RETRIEVAL_SETTINGS = {
    #  name: (words per piece, pieces fetched, re-rank?)
    "S1": (120, 6, False),
    "S2": (250, 4, False),
    "S3": (250, 4, True),
    "S4": (500, 3, False),
}
DEFAULT_SETTING = "S2"
LEAN_SETTING = "S1"       # used when the daily budget is low: fewer prompt tokens
WEAK_RETRIEVAL_SCORE = 1.0  # top BM25 score per query word; below this AND judged off-topic = refuse early


def load_calibration():
    """Overwrite defaults with what probe_groq.py measured on the real service."""
    path = os.path.join(os.path.dirname(__file__), "data", "calibration.json")
    global TPM_COUNTS_MAX_TOKENS
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            cal = json.load(f)
        for k in LIMITS:
            if cal.get(k):
                LIMITS[k] = cal[k]
        if "tpm_counts_max_tokens" in cal:
            TPM_COUNTS_MAX_TOKENS = cal["tpm_counts_max_tokens"]
        return cal
    return {}
