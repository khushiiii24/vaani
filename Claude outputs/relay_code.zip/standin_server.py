"""
The stand-in model service: a fake Groq that I control.

It speaks the same streaming API as Groq and can:
  - be slow          (first-token time drawn from the distribution measured on Groq)
  - fail             (some calls return HTTP 500/503)
  - refuse at a limit(429 with retry-after, like Groq, for RPM / TPM / RPD / TPD)
  - get slower under load (each request in flight beyond `capacity` adds delay)
  - succeed slowly   (a few calls are many times slower than normal)
  - stream           (sends the reply a few tokens at a time)

What text does it send? If the same prompt was sent to real Groq before, it
replays Groq's recorded answer (data/replay.json). Otherwise it makes a short
answer from the first passage in the prompt.

Run on its own:   python standin_server.py --scale 10
(run_load.py also starts it automatically for stand-in scenarios.)
"""
import argparse
import hashlib
import json
import math
import os
import random
import re
import threading
import time
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

DEFAULTS = {
    # timing, overwritten by data/calibration.json (measured on real Groq)
    "ttft_p50_ms": 250, "ttft_p95_ms": 700,     # first-token time spread (log-normal)
    "tokens_per_s": 500,                        # streaming speed after first token
    # failure behaviour (my choice; real Groq rarely failed in the probe)
    "error_rate": 0.02, "slow_rate": 0.03, "slow_factor": 10,
    # load behaviour: past `capacity` requests in flight, each extra one adds 15% delay
    "capacity": 8, "slowdown_per_extra": 0.15,
    # limits
    "rpm": 30, "tpm": 6000, "rpd": 14400, "tpd": 500000,
    "tpm_counts_max_tokens": True,
    "seed": 7,
}


def prompt_key(model, messages):
    return hashlib.sha1(json.dumps([model, messages], sort_keys=True).encode()).hexdigest()


class StandIn:
    def __init__(self, cfg):
        self.cfg = cfg
        self.lock = threading.Lock()
        self.minute_reqs = deque()     # timestamps of requests in the last 60 s
        self.minute_tokens = deque()   # (timestamp, tokens) in the last 60 s
        self.day_reqs = 0
        self.day_tokens = 0
        self.in_flight = 0
        self.peak_in_flight = 0
        self.rng = random.Random(cfg["seed"])
        # log-normal: median = p50, and p95 = median * exp(1.645 * sigma)
        self.mu = math.log(cfg["ttft_p50_ms"])
        self.sigma = max(0.05, math.log(cfg["ttft_p95_ms"] / cfg["ttft_p50_ms"]) / 1.645)
        self.replay = {}
        if os.path.exists("data/replay.json"):
            with open("data/replay.json", encoding="utf-8") as f:
                self.replay = json.load(f)

    # ------------------------------------------------------------ limits
    def check_limits(self, tokens):
        """Return None if allowed, else (retry_after_s, kind, message)."""
        c, now = self.cfg, time.time()
        with self.lock:
            while self.minute_reqs and now - self.minute_reqs[0] > 60:
                self.minute_reqs.popleft()
            while self.minute_tokens and now - self.minute_tokens[0][0] > 60:
                self.minute_tokens.popleft()
            used_tokens = sum(t for _, t in self.minute_tokens)
            if self.day_reqs + 1 > c["rpd"]:
                return 3600.0, "requests", f"Rate limit reached on requests per day (RPD): Limit {c['rpd']}"
            if self.day_tokens + tokens > c["tpd"]:
                return 3600.0, "tokens", f"Rate limit reached on tokens per day (TPD): Limit {c['tpd']}, Used {self.day_tokens}, Requested {tokens}"
            if len(self.minute_reqs) + 1 > c["rpm"]:
                wait = 60 - (now - self.minute_reqs[0])
                return wait, "requests", f"Rate limit reached on requests per minute (RPM): Limit {c['rpm']}. Please try again in {wait:.2f}s."
            if used_tokens + tokens > c["tpm"]:
                need, wait = used_tokens + tokens - c["tpm"], 1.0
                for ts, t in self.minute_tokens:     # wait until enough old tokens expire
                    need -= t
                    if need <= 0:
                        wait = 60 - (now - ts)
                        break
                return wait, "tokens", f"Rate limit reached on tokens per minute (TPM): Limit {c['tpm']}, Used {used_tokens}, Requested {tokens}. Please try again in {wait:.2f}s."
            self.minute_reqs.append(now)
            self.minute_tokens.append((now, tokens))
            self.day_reqs += 1
            self.day_tokens += tokens
            return None

    def headers(self):
        with self.lock:
            used = sum(t for _, t in self.minute_tokens)
            return {
                "x-ratelimit-limit-requests": str(self.cfg["rpd"]),
                "x-ratelimit-remaining-requests": str(max(0, self.cfg["rpd"] - self.day_reqs)),
                "x-ratelimit-limit-tokens": str(self.cfg["tpm"]),
                "x-ratelimit-remaining-tokens": str(max(0, self.cfg["tpm"] - used)),
            }

    # ------------------------------------------------------------ reply text
    def reply_text(self, model, messages):
        key = prompt_key(model, messages)
        if key in self.replay:
            return self.replay[key]
        user = messages[-1]["content"]
        if "Question:" in user and "[P1]" in user:     # drafting prompt: quote the first passage
            first = user.split("[P1]", 1)[1].split("\n", 1)[1]      # skip the "(paper, page)" line
            sentences = re.split(r"(?<=\.)\s", first.strip())
            sentence = next((s for s in sentences if len(s.split()) >= 6), sentences[0])[:300]
            return f"{sentence.rstrip('.')} [P1]."
        question = user.split("Question:")[-1].strip()      # understanding prompt
        return json.dumps({"on_topic": True, "paper": "any", "search": question})


def make_handler(si):
    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, *args):
            pass

        def send_json(self, code, obj, extra_headers=None):
            body = json.dumps(obj).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            for k, v in (extra_headers or {}).items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(body)

        def do_POST(self):
            req = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))))
            messages, model = req["messages"], req["model"]
            prompt_tokens = sum(len(m["content"]) for m in messages) // 4 + 8
            replayed = prompt_key(model, messages) in si.replay
            text = si.reply_text(model, messages)
            out_tokens = min(req.get("max_tokens", 300), max(1, len(text) // 4))

            # 1) limits. Whether the requested max output counts up front is taken from
            #    what probe_groq.py measured on real Groq (tpm_counts_max_tokens)
            counted = req.get("max_tokens", 300) if si.cfg["tpm_counts_max_tokens"] else out_tokens
            refused = si.check_limits(prompt_tokens + counted)
            if refused:
                wait, kind, msg = refused
                hdr = si.headers()
                hdr["retry-after"] = str(max(1, math.ceil(wait)))
                return self.send_json(429, {"error": {"message": msg, "type": kind,
                                                      "code": "rate_limit_exceeded"}}, hdr)
            # 2) random failure
            if si.rng.random() < si.cfg["error_rate"]:
                time.sleep(si.rng.uniform(0.05, 0.4))
                return self.send_json(si.rng.choice([500, 503]),
                                      {"error": {"message": "internal error (stand-in)"}})

            with si.lock:
                si.in_flight += 1
                si.peak_in_flight = max(si.peak_in_flight, si.in_flight)
                load = 1 + si.cfg["slowdown_per_extra"] * max(0, si.in_flight - si.cfg["capacity"])
            try:
                ttft = math.exp(si.rng.gauss(si.mu, si.sigma)) / 1000 * load
                if si.rng.random() < si.cfg["slow_rate"]:
                    ttft *= si.cfg["slow_factor"]          # succeeds, but slowly
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.send_header("Transfer-Encoding", "chunked")
                for k, v in si.headers().items():
                    self.send_header(k, v)
                self.send_header("x-standin-replayed", "1" if replayed else "0")  # 0 = invented text
                self.end_headers()
                time.sleep(ttft)
                # 3) stream the reply ~4 characters (one token) at a time, in small groups
                step = 12
                per_piece = (step / 4) / (si.cfg["tokens_per_s"] / load)
                for i in range(0, len(text), step):
                    self.write_event({"choices": [{"index": 0, "delta": {"content": text[i:i + step]}}]})
                    time.sleep(per_piece)
                self.write_event({"choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
                                  "x_groq": {"usage": {"prompt_tokens": prompt_tokens,
                                                       "completion_tokens": out_tokens}}})
                self.write_chunk(b"data: [DONE]\n\n")
                self.write_chunk(b"")
            except (BrokenPipeError, ConnectionResetError):
                pass
            finally:
                with si.lock:
                    si.in_flight -= 1

        def write_event(self, obj):
            self.write_chunk(f"data: {json.dumps(obj)}\n\n".encode())

        def write_chunk(self, data):
            self.wfile.write(f"{len(data):x}\r\n".encode() + data + b"\r\n")
            self.wfile.flush()

    return Handler


class QuietServer(ThreadingHTTPServer):
    daemon_threads = True
    request_queue_size = 256    # default backlog is 5: a burst of 30 connections would sit in
                                # TCP retry (1 s, 2 s, 4 s ...) and look like a slow model

    def handle_error(self, request, client_address):
        pass                    # a client that hung up (timeout) is normal here, not an error


def start(overrides=None, port=8100):
    """Start the stand-in in a background thread. Returns (server, StandIn)."""
    cfg = dict(DEFAULTS)
    if os.path.exists("data/calibration.json"):
        with open("data/calibration.json", encoding="utf-8") as f:
            cal = json.load(f)
        for k in ("ttft_p50_ms", "ttft_p95_ms", "tokens_per_s", "rpm", "tpm", "rpd", "tpd",
                  "error_rate", "tpm_counts_max_tokens"):
            if k in cal and cal[k] is not None:
                cfg[k] = cal[k]
    cfg.update(overrides or {})
    si = StandIn(cfg)
    server = QuietServer(("127.0.0.1", port), make_handler(si))
    server.daemon_threads = True
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server, si


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--scale", type=float, default=1.0, help="multiply per-minute limits")
    ap.add_argument("--port", type=int, default=8100)
    a = ap.parse_args()
    server, si = start(port=a.port)
    si.cfg["rpm"] = int(si.cfg["rpm"] * a.scale)
    si.cfg["tpm"] = int(si.cfg["tpm"] * a.scale)
    print("stand-in running on port", a.port, "with", si.cfg)
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        server.shutdown()
